try { __liberator_eval_result = eval(__liberator_eval_string);
}
catch (e) {
    __liberator_eval_error = e;
}
// IMPORTANT: The eval statement *must* remain on the first line
// in order for line numbering in any errors to remain correct.

// Copyright (c) 2008-2009 by Kris Maglione <maglione.k at Gmail>
//
// This work is licensed for reuse under an MIT license. Details are
// given in the License.txt file included with this file.

// vim: set fdm=marker sw=4 ts=4 et:
