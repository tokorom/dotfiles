({updated:1406881910353, items:[{domain:"^https?://use\\.perl\\.org/~\\w+/journal/", paragraph:"descendant::div[@id = \"journalslashdot\"]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" adminoptions \")]/descendant::a[not(following-sibling::*)]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h3"}, {domain:"^https?://use\\.perl\\.org/article.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" article \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" commentBox \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://www\\.facebook\\.com/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" uiStreamSubstory \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" uiStreamSource \")]/descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" UIActionLinks \")]"}, {domain:"^https?://(?:[w-]+.)*fc2\\.com/.*html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" left \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://blog\\.days\\.yahoo\\.co\\.jp/blog$", paragraph:"descendant::div[@id = \"mgbp_title\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://s\\.hatena\\.com/siteconfig", paragraph:"descendant::h2", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*ascii\\.jp/elem/\\d+/\\d+/\\d+/\\d+/", paragraph:"descendant::div[@id = \"contdefault\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*ascii\\.jp/cate/15/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" namegroups \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*ascii\\.jp/cate/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" namegroup \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*ascii\\.jp/cate/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" pickupsc \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*techcrunch\\.com/.*$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*seesaa\\.net/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://www\\.iza\\.ne\\.jp/news/newsarticle/", paragraph:"descendant::div[@id = \"izanews_detail\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" contents_title \")]"}, {domain:"^https?://b\\.hatena\\.ne\\.jp/Yuichirou/", paragraph:"descendant::dl[contains(concat(\" \", normalize-space(@class), \" \"), \" bookmarklist \")]", link:"descendant::dt[contains(concat(\" \", normalize-space(@class), \" \"), \" bookmark \")]/descendant::a", annotation:"descendant::dt[contains(concat(\" \", normalize-space(@class), \" \"), \" bookmark \")]"}, {domain:"^https?://b\\.hatena\\.ne\\.jp/bookmarklist", paragraph:"descendant::dl[contains(concat(\" \", normalize-space(@class), \" \"), \" bookmarklist \")]", link:"descendant::dd[contains(concat(\" \", normalize-space(@class), \" \"), \" bookmarker \")]/descendant::a", annotation:"descendant::dd[contains(concat(\" \", normalize-space(@class), \" \"), \" comment \")]"}, {domain:"^https?://prcm\\.jp/album/\\w+/pic/\\w+$", paragraph:"descendant::*[@id = \"contents\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://www\\.example\\.net/", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[count(preceding-sibling::*) = 1]"}, {domain:"^https?://(?:[w-]+.)*blog52\\.fc2\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://delicious\\.com/url/[\\w]+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" data \")]/child::h4", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://delicious\\.com.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" data \")]/descendant::h4", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://wiki\\.monaos\\.org/(index|pukiwiki).php$", paragraph:"descendant::div[@id = \"Panels\"]/descendant::ul/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://www\\.discogs\\.com/release/.*$", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://qiita\\.com/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" item-box \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" item-box-title \")]/descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" item-box-title \")]"}, {domain:"^https?://qiita\\.com/items", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" comment-box \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" comment-post-time \")]/descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" comment-user-name \")]"}, {domain:"^https?://wonderfl\\.kayac\\.com/code/[0-9a-f]+$", paragraph:"descendant::div[@id = \"code_title_wrapper\"]", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" code_meta_right \")]"}, {domain:"^https?://(?:[w-]+.)*ap\\.teacup\\.com/[\\w-]+/\\d+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" postdate \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" posttitle \")]"}, {domain:"^https?://(?:[w-]+.)*ap\\.teacup\\.com/([\\w-]+/|applet/[\\w-]+/)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" postdate \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" postcommtb \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" posttitle \")]"}, {domain:"^https?://ido\\.nu.*/", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://theinterviews\\.jp/[\\w-]+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" log \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://theinterviews\\.jp/[\\w-]+/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" log \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://ja\\.uncyclopedia\\.info/wiki/", paragraph:"descendant::*[@id = \"content\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[@id = \"firstHeading\"]/descendant::span"}, {domain:"^https?://(?:[w-]+.)*cocolog\\-nifty\\.com/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*typepad\\.com.*/\\d+/\\d+/.*\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*typepad\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]"}, {domain:"^https?://kamawada\\.com/~masanori/blog/", paragraph:"descendant::div[@id = \"alpha-inner\"]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-footer \")]/descendant::a", annotation:"descendant::h2[@id = \"archive-title\"]"}, {domain:"^https?://inezha\\.com/p/6182566$", paragraph:"descendant::div[@id = \"main\"]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::div[@id = \"main\"]"}, {domain:"^https?://javadoc\\.geotools\\.fr/.*/(?!package-frame)", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://community\\.travel\\.yahoo\\.co\\.jp/mymemo/[\\w-_]+/blog/.*html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" ytrvTmMdTdArticle \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://community\\.travel\\.yahoo\\.co\\.jp/mymemo/[\\w-_]+/buzz/.*html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" ytrvTmMdRepArticle \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3/descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" span02 \")]"}, {domain:"^https?://addons\\.mozilla\\.org/.+/.+/addon/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" addon-feature \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://addons\\.mozilla\\.org/.+/.+/browse/.+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" addon-listitem \")]", link:"descendant::a", annotation:"descendant::h2"}, {domain:"^https?://addons\\.mozilla\\.org/.+/.+/recommended$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" addon-listitem \")]", link:"descendant::a", annotation:"descendant::h2"}, {domain:"^https?://www\\.google\\.com/search$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" g \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" l \")]", annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" r \")]"}, {domain:"^https?://(?:[w-]+.)*g\\.hatena\\.ne\\.jp/bbs/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" day \")]", link:"descendant::h2/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*g\\.hatena\\.ne\\.jp/[\\w-]+/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" hatena-section \")]/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://twitter\\.com/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" tweet \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink-link \")] | descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" tweet-timestamp \")] | descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" embed-link \")]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" js-tweet-text \")]"}, {domain:"^https?://wooser\\.blog4\\.fc2\\.com/.*html$", paragraph:"descendant::div[@id = \"main\"]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://wiredvision\\.jp.+/\\d+\\.html$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" linklist \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*pixiv\\.net/member\\.php$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" image-item \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*pixiv\\.net/member_illust\\.php$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" cool-work-main \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" date \")]"}, {domain:"^https?://geoapi\\.sourceforge\\.net/2.0/javadoc/.*/(?!package-frame)", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://togetter\\.com/li/\\d+", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" list_item \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" status_right \")]/descendant::a[not(following-sibling::*)]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" status_right \")]"}, {domain:"^https?://www\\.tez\\.com/blog/archives/\\d+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-footer \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]"}, {domain:"^https?://www\\.tez\\.com/blog/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-footer \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]"}, {domain:"^https?://blog\\.amuse\\.co\\.jp/perfume/p/archive/\\d+/\\d+-\\d+-\\d+\\.php", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" day \")]/child::h2"}, {domain:"^https?://blog\\.amuse\\.co\\.jp/perfume/p/item/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" day \")]/descendant::h2"}, {domain:"^https?://www\\.nikkansports\\.com/$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" newslist \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.nikkansports\\.com/[\\w/]+top-\\w+\\.html$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" newslist \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.nikkansports\\.com/[\\w/]+\\w-[\\w-]+\\.html$", paragraph:"descendant::div[@id = \"news\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*jugem\\.jp/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_state \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]"}, {domain:"^https?://maker\\.usoko\\.net/nounai/r/", paragraph:"descendant::div[@id = \"con_main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://mainichi\\.jp/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" tophl-body \")]/descendant::ul/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://mainichi\\.jp/select/\\w+/news/\\w+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" newsarticle \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" newstitle \")]"}, {domain:"^https?://mainichi\\.jp/enta/\\w+/\\w+/news/\\w+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" newsarticle \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" newstitle \")]"}, {domain:"^https?://mainichi\\.jp/select/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" m-body01 \")]/descendant::a", link:"self::*", annotation:"self::*"}, {domain:"^https?://mainichi\\.jp/enta/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" m-body01 \")]/descendant::a", link:"self::*", annotation:"self::*"}, {domain:"^https?://mainichi\\.jp/select/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" m-body01 \")]/descendant::a", link:"self::*", annotation:"self::*"}, {domain:"^https?://mainichi\\.jp/select/\\w+/archive/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" mainmargin \")]/descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" mark \")]/descendant::li/descendant::a", link:"self::*", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*gigazine\\.net/$", paragraph:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*gigazine\\.net/index\\.php?", paragraph:"descendant::div[@id = \"maincol\"]/descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" content \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://www\\.kanshin\\.com/user/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a", annotation:"descendant::h4"}, {domain:"^https?://www\\.kanshin\\.com/keyword/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" ColA \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.kanshin\\.com/diary/\\d+$", paragraph:"descendant::div[@id = \"entry\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://www\\.kanshin\\.com/keyword/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" keyword \")]", link:"descendant::a", annotation:"descendant::ul"}, {domain:"^https?://www\\.kanshin\\.com/diary/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a", annotation:"descendant::ul"}, {domain:"^https?://www\\.kanshin\\.com/user/\\d+/keyword", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" keyword \")]", link:"descendant::a", annotation:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" sub \")]"}, {domain:"^https?://www\\.kanshin\\.com/user/\\d+/diary", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a", annotation:"descendant::h3"}, {domain:"^https?://www\\.kanshin\\.com/collection/\\d+$", paragraph:"descendant::div[@id = \"collection\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.kanshin\\.com/community/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" header \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://plaza\\.rakuten\\.co\\.jp/\\w+/diary/\\d+/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" DIV \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h4[contains(concat(\" \", normalize-space(@class), \" \"), \" h4 \") and not(preceding-sibling::*)]/descendant::td[not(preceding-sibling::*)]"}, {domain:"^https?://plaza\\.rakuten\\.co\\.jp/\\w+($|/$|/diary/$)", paragraph:"descendant::h4[contains(concat(\" \", normalize-space(@class), \" \"), \" h4 \")]", link:"descendant::td/descendant::a", annotation:"descendant::td"}, {domain:"^https?://playlog\\.jp/\\w+/blog/[\\d-]+", paragraph:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title-area-single \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://playlog\\.jp/\\w+/blog/", paragraph:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title-area \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"self::*"}, {domain:"^https?://s\\.hatena\\.ne\\.jp/siteconfig", paragraph:"descendant::h2", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://oshiete1\\.goo\\.ne\\.jp/search_pv\\.php3", paragraph:"descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list \")]/descendant::tr", link:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list_content \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list_content \")]/descendant::a[not(preceding-sibling::*)]"}, {domain:"^https?://oshiete1\\.goo\\.ne\\.jp/c\\d+\\.html$", paragraph:"descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list \")]/descendant::tr", link:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list_content \")]/descendant::a", annotation:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" ok_list_content \")]/descendant::a"}, {domain:"^https?://code\\.nanigac\\.com/source/view/", paragraph:"descendant::div[@id = \"main\"]", link:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" detail_tit \")]/descendant::a", annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" detail_tit \")]"}, {domain:"^https?://mixi\\.jp/list_diary\\.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" listDiaryTitle \")]", link:"descendant::dt/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::dt"}, {domain:"^https?://mixi\\.jp/new_friend_diary\\.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" newFriendDiaryArea \")]/descendant::li", link:"descendant::dd/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::dd"}, {domain:"^https?://mixi\\.jp/view_diary\\.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" listDiaryTitle \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::dt"}, {domain:"^https?://mixi\\.jp/(re(cent|s)|list)_echo\\.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" archiveList \")]/descendant::tr", link:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" comment \")]/descendant::span[not(preceding-sibling::*)]/descendant::a", annotation:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" comment \")]"}, {domain:"^https?://mixi\\.jp/view_echo\\.pl", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" echoStatus \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[not(preceding-sibling::*)]"}, {domain:"^https?://mixi\\.jp/recent_voice\\.pl", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" archive \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" voiced \")]/descendant::p/descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" voiced \")]/descendant::p/descendant::span"}, {domain:"^https?://(?:[w-]+.)*269g\\.net/", paragraph:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.vividsolutions\\.com/jts/javadoc/.*/(?!package-frame)", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://www\\.vividsolutions\\.com/jts/javadoc/overview-frame.html$", paragraph:"descendant::font[contains(concat(\" \", normalize-space(@class), \" \"), \" FrameItemFont \")]", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://www\\.infoq\\.com/jp/news/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box-content-5 \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" info \")]"}, {domain:"^https?://piapro\\.jp/content/?", paragraph:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" icon_ill \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://piapro\\.jp/content/?", paragraph:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" icon_snd \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://piapro\\.jp/content/?", paragraph:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" icon_lyc \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*tea\\-nifty\\.com/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://www\\.st\\.ryukoku\\.ac\\.jp/~kjm/security/memo/", paragraph:"descendant::li/descendant::p", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" nu \")]", annotation:"self::*"}, {domain:"^https?://www\\.cyzo\\.com/\\d+/\\d+/\\w+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-asset \")]", link:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-title \")]/descendant::a", annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-title \")]"}, {domain:"^https?://blog\\.livedoor\\.jp/dankogai/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::h3/child::a[contains(concat(\" \", normalize-space(@class), \" \"), \" aposted \")]", annotation:"descendant::h3"}, {domain:"^https?://blog\\.livedoor\\.jp/dankogai/archives/\\d+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://blog\\.livedoor\\.jp/[\\w-]+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" posted \")]/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://blog\\.livedoor\\.jp/[\\w-]+/archives/\\d+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://www\\.slideshare\\.net/[^/]*/[^/]*/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" zingedright \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*blog\\.shinobi\\.jp/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_table \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://nounaimaker\\.com/", paragraph:"descendant::div[@id = \"con_main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*blog55\\.fc2\\.com/$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_table \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]"}, {domain:"^https?://(?:[w-]+.)*blog55\\.fc2\\.com/blog-(entry|date|category)-\\d+\\.html$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_table \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]"}, {domain:"^https?://erockr\\.com/archive/(.+)$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::*[@id = \"hatena-star\"]/child::a", annotation:"descendant::*[@id = \"hatena-star\"]"}, {domain:"^https?://diary\\.sorah\\.jp/", paragraph:"descendant::article[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h1/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" categories \")]"}, {domain:"^https?://del\\.icio\\.us/url/[\\w]+", paragraph:"descendant::h4[contains(concat(\" \", normalize-space(@class), \" \"), \" nomb \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://del\\.icio\\.us.*.*", paragraph:"descendant::ol[contains(concat(\" \", normalize-space(@class), \" \"), \" posts \")]/descendant::li", link:"descendant::h4/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" commands \")]"}, {domain:"^https?://misao\\.on\\.arena\\.ne\\.jp.*/upload.cgi$", paragraph:"descendant::p", link:"descendant::a[not(preceding-sibling::*)]", annotation:"self::*"}, {domain:"^https?://www\\.nicovideo\\.jp/watch/\\w+", paragraph:"descendant::div[@id = \"WATCHHEADER\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" video_title \")]"}, {domain:"^https?://japanese\\.engadget\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]/descendant::h2", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://japanese\\.engadget\\.com/\\d+/\\d+/\\d+/[\\w-]+/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]/descendant::h2", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://dic\\.nicovideo\\.jp/a/*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" article-tab-nico \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://sa\\.yona\\.la/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-box \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://calwinefood\\.blog51\\.fc2\\.com.*.+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" main_block \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" main_title \")]/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" main_title \")]/descendant::td"}, {domain:"^https?://(?:[w-]+.)*exblog\\.jp/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" TIME \")]/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" POST_TTL \")]"}, {domain:"^https?://(?:[w-]+.)*livedoor\\.biz/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"self::*", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*livedoor\\.biz/archives/\\d+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"self::*", annotation:"self::*"}, {domain:"^https?://blog\\.excite\\.co\\.jp/[\\w-]+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" TIME \")]/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" POST_TTL \")]"}, {domain:"^https?://blogs\\.yahoo\\.co\\.jp/\\w+/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"self::*", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*way\\-nifty\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*way\\-nifty\\.com/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*way\\-nifty\\.com/\\w+/\\d+/\\d+/.+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://ralf\\-halfmoon\\.jugem\\.jp/.$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]"}, {domain:"^https?://www\\.mai\\-net\\.net/bbs/sst/sst.php$", paragraph:"descendant::tr[contains(concat(\" \", normalize-space(@class), \" \"), \" bgc \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::a"}, {domain:"^https?://(?:[w-]+.)*blogspot\\.com.*.*", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" hentry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" timestamp-link \")]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" post-footer-line-1 \")]"}, {domain:"^https?://jp\\.techcrunch\\.com/archives/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post_subheader \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post_subheader_left \")]"}, {domain:"^https?://(?:[w-]+.)*txt\\-nifty\\.com/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://pics\\.livedoor\\.com/u/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" photo-box \")]", link:"descendant::h3/descendant::a", annotation:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" stats \")]"}, {domain:"^https?://pics\\.livedoor\\.com/u/\\w+/\\d+", paragraph:"descendant::div[@id = \"container\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" stats-detail \")]"}, {domain:"^https?://pics\\.livedoor\\.com/u/\\w+/(photos|movies|magical_maker)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" p-box \")]", link:"descendant::h4[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" stats \")]"}, {domain:"^https?://pics\\.livedoor\\.com(/u/\\w+)?/t/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" p-box \")]", link:"descendant::h4[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h4"}, {domain:"^https?://ttyshare\\.com/rec/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" meta \")]"}, {domain:"^https?://ttyshare\\.com.*.*", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" recent_entry \")]", link:"descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*youtube\\.com/watch?", paragraph:"descendant::div[@id = \"baseDiv\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[@id = \"vidTitle\"]"}, {domain:"^https?://www\\.afpbb\\.com.+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" headlineList \")]/descendant::div/descendant::ul/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://smatsu\\.air\\-nifty\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://la\\.ma\\.la/blog/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/child::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" posted \")]"}, {domain:"^https?://www\\.cyzowoman\\.com/\\d+/\\d+/\\w+\\.html$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" entrybodyHead \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://www\\.trick7\\.com/blog/\\d+/\\d+/.+.php$", paragraph:"descendant::div[@id = \"main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.trick7\\.com/blog/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/child::a", annotation:"descendant::h2"}, {domain:"^https?://www\\.youtube\\.com/watch?", paragraph:"descendant::div[@id = \"baseDiv\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[@id = \"vidTitle\"]"}, {domain:"^https?://ascii\\.jp/elem/\\d+/\\d+/\\d+/\\d+/", paragraph:"descendant::div[@id = \"contdefault\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://ascii\\.jp/cate/15/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" namegroups \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://ascii\\.jp/cate/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" namegroup \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://ascii\\.jp/cate/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" pickupsc \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://internet\\.watch\\.impress\\.co\\.jp/static/yajiuma/\\d{4}/\\d{2}/", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" body-text \")]/child::a", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" news \")]", annotation:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" news \")]"}, {domain:"^https?://internet\\.watch\\.impress\\.co\\.jp/$", paragraph:"descendant::table[count(preceding-sibling::*) = 2]/descendant::table[count(preceding-sibling::*) = 2]/descendant::table/descendant::tr", link:"descendant::td/descendant::a", annotation:"descendant::td/descendant::a"}, {domain:"^https?://twitpaint\\.com/graffiti/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" list \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" left \")]/descendant::a", annotation:"self::*"}, {domain:"^https?://twitpaint\\.com/[0-9a-z]{6,7}$", paragraph:"descendant::div[@id = \"contents\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://project\\-nagi\\.com/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]", annotation:"descendant::h3"}, {domain:"^https?://maruta\\.be/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-asset \")]", link:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" asset-name \")]/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://handa\\.ifdef\\.jp.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" post-title \")]/descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" post-footer \")]"}, {domain:"^https?://(?:[w-]+.)*nowa\\.jp/entry/[\\w]+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]/descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-title \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*nowa\\.jp/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-inner \")]", link:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-title \")]/descendant::a", annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-title \")]"}, {domain:"^https?://(?:[w-]+.)*nowa\\.jp/status/$", paragraph:"descendant::dl[contains(concat(\" \", normalize-space(@class), \" \"), \" newest-doing \")]", link:"descendant::dt/descendant::span/descendant::a", annotation:"descendant::dd/descendant::div"}, {domain:"^https?://anond\\.hatelabo\\.jp.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" section \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://en\\.wikipedia\\.org/wiki/[^&]+$", paragraph:"descendant::div[@id = \"globalWrapper\"]", link:"descendant::*[@id = \"p-cactions\"]/descendant::ul[not(preceding-sibling::*)]/descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" selected \")]/descendant::a", annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" firstHeading \")]"}, {domain:"^https?://yaplog\\.jp/yurisii/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/child::a", annotation:"descendant::h3"}, {domain:"^https?://yaplog\\.jp/yurisii/archive/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://yaplog\\.jp/strawberry2/(archive/\\d+)?$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/child::a", annotation:"descendant::h2"}, {domain:"^https?://yaplog\\.jp/[\\w-]+/archive/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::h2 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog_title \")]/descendant::h2 | descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_bgmain \")]/descendant::h2", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://yaplog\\.jp/[\\w-]+/($|\\d+$|category|daily|monthly)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::h2 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")]/descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog_title \")]/descendant::h2 | descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_bgmain \")]/descendant::h2", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://journal\\.mycom\\.co\\.jp/(index\\.html$|$)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" section \")]/descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" headlinelist01 \")]/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://journal\\.mycom\\.co\\.jp/\\w+/\\w+/\\w+/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" section \")]/child::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" linklist01 \")]/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://journal\\.mycom\\.co\\.jp/\\w+/\\w+/($|index\\.html$)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" section \")]/child::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" linklist01 \")]/descendant::li", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://www\\.moongift\\.jp/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://www\\.moongift\\.jp/\\d{4}/\\d{2}/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://www\\.moongift\\.jp/category/.*/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://www\\.moongift\\.jp/\\d{4}/\\d{2}/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://jp\\.blogherald\\.com/\\d+/\\d+/\\d+/[\\w-]*/$", paragraph:"descendant::div[@id = \"single_post\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.akibablog\\.net/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" content \")]/descendant::h3", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.akibablog\\.net/archives/[\\w-/]+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" content \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" kobetutitle \")]"}, {domain:"^https?://(?:[w-]+.)*blog4\\.fc2\\.com/.*html$", paragraph:"descendant::div[@id = \"main\"]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://nijinochocolate\\.homelinux\\.net/niji/head_[\\w_]+\\d+\\.html$", paragraph:"descendant::table[count(preceding-sibling::*) = 1]/descendant::dl", link:"descendant::dd/descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::dd/descendant::a[count(preceding-sibling::*) = 1]"}, {domain:"^https?://nijinochocolate\\.homelinux\\.net/niji/msg_[\\d_]+\\.html$", paragraph:"descendant::table[count(preceding-sibling::*) = 1]/descendant::dl", link:"descendant::dd/descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::dd/descendant::a[count(preceding-sibling::*) = 1]"}, {domain:"^https?://q\\.hatena\\.ne\\.jp/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" comment-title \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*blog30\\.fc2\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" left \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://twitpic\\.com/", paragraph:"descendant::div[@id = \"media-main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[@id = \"media-caption\"]"}, {domain:"^https?://twitpic\\.com/photos/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" user-photo-wrap \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" meta \")]/descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" inline-list \")]/descendant::li[count(preceding-sibling::*) = 1]"}, {domain:"^https?://gigazine\\.net/$", paragraph:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://gigazine\\.net/index\\.php?", paragraph:"descendant::div[@id = \"maincol\"]/descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" content \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://www\\.niconicommons\\.jp/material/", paragraph:"descendant::*[@id = \"index_content\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.niconicommons\\.jp/tree/", paragraph:"descendant::*[@id = \"tree_n\"]/descendant::p[not(following-sibling::*)]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.niconicommons\\.jp/$|^/\\?t=|^/recent/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" cmn_thumb_frm \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" TXT12 \") and not(preceding-sibling::*)]/descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" TXT12 \") and not(preceding-sibling::*)]"}, {domain:"^https?://java\\.sun\\.com/j2se/1.5.0(/[a-z]+)?/docs(/[a-z]+)?/api/.*/(?!package-frame)", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://ja\\.wikipedia\\.org/wiki/[^&]+$", paragraph:"descendant::div[@id = \"content\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" firstHeading \")]"}, {domain:"^https?://fixdap\\.com/p/", paragraph:"descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" tasklist \")]/descendant::tr", link:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" tasktitle \")]/descendant::a", annotation:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" tasktitle \")]"}, {domain:"^https?://portal\\.nifty\\.com/\\d+/\\d+/\\d+/\\w+", paragraph:"descendant::td/child::table/descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" tx12px \")]/descendant::b", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://digg\\.com.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" news-body \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://flickr\\.com/photos/[@\\w-]+/\\d+/$", paragraph:"descendant::*[@id = \"photoswftd\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://flickr\\.com/photos/[@\\w-]+/?", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" PhotosColumn \")]/child::table/descendant::td", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" Activity \")]"}, {domain:"^https?://flickr\\.com/explore/$", paragraph:"descendant::div[@id = \"Main\"]", link:"descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" Interestingness \")]/child::tbody/child::tr/child::td/child::a", annotation:"descendant::h1"}, {domain:"^https?://www\\.asahi\\.com/$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.asahi\\.com/\\w+/update/\\w+/\\w+\\.html", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" update \")] | descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" Update \")]"}, {domain:"^https?://www\\.asahi\\.com/\\w+/\\w+/\\w+\\.html", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" update \")] | descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" Update \")]"}, {domain:"^https?://www\\.asahi\\.com/list\\.html", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" update \")] | descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" Update \")]"}, {domain:"^https?://www\\.asahi\\.com/\\w+/(\\w+\\.html|$)", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" update \")] | descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" Update \")]"}, {domain:"^https?://www\\.asahi\\.com/\\w+/\\w+/$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" Lnk \")]/descendant::li", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" update \")] | descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" Update \")]"}, {domain:"^https?://kichiku\\.oq\\.la/\\d*$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" recentEntry \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" usertext \")]/descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" created_at \")]"}, {domain:"^https?://kichiku\\.oq\\.la/show/\\d+$", paragraph:"descendant::div[@id = \"maincontent\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p"}, {domain:"^https?://www\\.example\\.com/", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[count(preceding-sibling::*) = 1]"}, {domain:"^https?://recompile\\.net/\\d", paragraph:"descendant::*[@id = \"archive-title\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://recompile\\.net/", paragraph:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-header \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://tools\\.ietf\\.org/html/rfc\\d+$", paragraph:"descendant::pre", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" h1 \") and not(preceding-sibling::*)]"}, {domain:"^https?://blog\\.goo\\.ne\\.jp/[\\w-]+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]/descendant::h2 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_title \")] | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-top \")]/descendant::h2 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-top \")]/descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_tt \")]/descendant::p | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" eTitle \")] | descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" etTitle \")] | descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")] | descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")] | descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" entryHead \")] | descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_top \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://blog\\.goo\\.ne\\.jp/[\\w_-]+/e/[\\w\\d]+$", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" tbg03 \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" etTitleLink \")]", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" etTitle \")]"}, {domain:"^https?://www\\.shibukei\\.com/$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.shibukei\\.com/(headline|special)/archives/.+$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.shibukei\\.com/headline/\\d+/index.html$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.shibukei\\.com/column/\\d+/index.html$", paragraph:"descendant::div[@id = \"column\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p"}, {domain:"^https?://localhost/$", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*hito\\.thebbs\\.jp/one/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" naka \")]", link:"descendant::h3/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://www\\.hamakei\\.com/$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.hamakei\\.com/(headline|special)/archives/.+$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.hamakei\\.com/headline/\\d+/index.html$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.hamakei\\.com/column/\\d+/index.html$", paragraph:"descendant::div[@id = \"column\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p"}, {domain:"^https?://www\\.hirokiazuma\\.com/archives/\\w+.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://bizmakoto\\.jp/makoto/articles/.+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" newart \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://linguafuranca\\.blog97\\.fc2\\.com/blog-entry-\\d+.html$", paragraph:"descendant::div[@id = \"main\"]", link:"descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" a_title \")]"}, {domain:"^https?://jaiku\\.com(/$|/\\??page=\\d)", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" stream \")]/descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" presence \")]/descendant::div/descendant::div", link:"descendant::h3/descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" meta \")]"}, {domain:"^https?://jaiku\\.com/presence/\\w+", paragraph:"descendant::div[@id = \"current-stream\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p"}, {domain:"^https?://diary\\.jp\\.aol\\.com/\\w+/$", paragraph:"descendant::*[@id = \"recententry\"]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www\\.tinami\\.com/view/\\d+$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" viewdata \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.tinami\\.com/search/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" result_list \")]/descendant::td", link:"descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" capt \")]"}, {domain:"^https?://(?:[w-]+.)*getpersonas\\.com/\\w+/gallery", paragraph:"descendant::*[@id = \"gallery\"]/descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" gallery-item \")]", link:"descendant::div/descendant::h3/descendant::a", annotation:"descendant::div/descendant::h3"}, {domain:"^https?://(?:[w-]+.)*getpersonas\\.com/\\w+/persona/\\d+", paragraph:"descendant::*[@id = \"maincontent\"]/descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" persona-detail \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://photozou\\.jp/photo/show/\\d+/\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" media_padding \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" favorite \")]"}, {domain:"^https?://www\\.concorde\\.gr\\.jp/~hibiki/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-asset \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" asset-meta \")]/child::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h2"}, {domain:"^https?://www\\.concorde\\.gr\\.jp/~hibiki/hotchpotch/\\d+/\\d+/.+\\.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-asset \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" asset-meta \")]/child::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h1"}, {domain:"^https?://my\\.nowa\\.jp/friend/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" friendentry-box \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" time \")]/descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" blue-cms \")]", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" time \")]"}, {domain:"^https?://knowledge\\.livedoor\\.com/\\w+/(\\d+)*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" listboxin \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" listboxtxt \")]/descendant::h3/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" listboxtxt \")]/descendant::h3"}, {domain:"^https?://(?:[w-]+.)*keizai\\.biz/$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*keizai\\.biz/(headline|special)/archives/.+$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*keizai\\.biz/headline/\\d+/index.html$", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" arrow \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*keizai\\.biz/column/\\d+/index.html$", paragraph:"descendant::div[@id = \"column\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p"}, {domain:"^https?://headlines\\.yahoo\\.co\\.jp/hl", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" cptComment \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" hdTop \")]"}, {domain:"^https?://(?:[w-]+.)*typepad\\.jp.*/\\d+/\\d+/.*\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*typepad\\.jp/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/child::a", annotation:"descendant::h3"}, {domain:"^https?://totoshan\\.blog52\\.fc2\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2"}, {domain:"^https?://www\\.j\\-cast\\.com/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" text-column \")]/descendant::h3", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://www\\.j\\-cast\\.com/\\d+/\\d+/\\d+\\.html$", paragraph:"descendant::div[@id = \"entry\"]/descendant::h1", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*zen\\.seesaa\\.net/.*$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h2[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://github\\.com/\\w+/*$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" path \")]", link:"descendant::b/descendant::a", annotation:"descendant::b"}, {domain:"^https?://github\\.com/\\w+/?$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" path \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::a[not(preceding-sibling::*)]"}, {domain:"^https?://(?:[w-]+.)*theinterviews\\.jp/[\\w-]+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" log \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://(?:[w-]+.)*theinterviews\\.jp/[\\w-]+/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" log \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://wedata\\.net/$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" hentry \")]", link:"descendant::a", annotation:"descendant::a"}, {domain:"^https?://wedata\\.net/databases/.*/items$", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" hentry \")]", link:"descendant::a", annotation:"descendant::div"}, {domain:"^https?://wedata\\.net/items/.*$", paragraph:"descendant::*[@id = \"content\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://photobox\\.ddo\\.jp/ping/thumbnail.html", paragraph:"descendant::div[@id = \"honbun\"]/child::ul/child::li", link:"descendant::a", annotation:"descendant::div[not(preceding-sibling::*)]"}, {domain:"^https?://d\\.hatena\\.com/[\\w-]+/", paragraph:"descendant::h3", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://blog\\.pixiv\\.net/$", paragraph:"descendant::div[@id = \"pixiv\"]/descendant::div[@id = \"leftcolumn\"]/descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry_post \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*slmame\\.com/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blogbody \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://blog\\.geeko\\.jp/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://wassr\\.jp/user/[\\w]+/statuses/[\\w]+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" MsgBody \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" message \")]"}, {domain:"^https?://wassr\\.jp/timeline/public", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" MsgBody \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" messagefoot \")]/descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" message \")]"}, {domain:"^https?://wassr\\.jp/my/|/user/[\\w]+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" MsgBody \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" messagefoot \")]/descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" message \")]"}, {domain:"^https?://(?:[w-]+.)*moe\\-nifty\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://ask\\.fm/\\w+(/best)?$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" questionBox \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" link-time \")]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" question \")]"}, {domain:"^https?://ask\\.fm/\\w+/answer/\\d+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" questionBox \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" link-time \")]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" question \")]"}, {domain:"^https?://tuchinoko\\.moe\\-nifty\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://mytown\\.asahi\\.com/\\w+/news\\.php?", paragraph:"descendant::div[@id = \"cnt\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://clubt\\.jp/product/\\d+_\\d+.html", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" meta_box_site \")]", link:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" site_name \")]/descendant::a", annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" site_name \")]"}, {domain:"^https?://(?:[w-]+.)*air\\-nifty\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]", annotation:"descendant::h3"}, {domain:"^https?://sankei\\.jp\\.msn\\.com/(top\\.htm|$)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" region6 \")]/descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" singlelist1 \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://sankei\\.jp\\.msn\\.com/\\w+/\\w+/\\d+/[\\w-]+\\.htm$", paragraph:"descendant::div[@id = \"articleTextnews1\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.flickr\\.com/photos/[@\\w-]+/\\d+/$", paragraph:"descendant::*[@id = \"photoswftd\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://www\\.flickr\\.com/photos/[@\\w-]+/?", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" PhotosColumn \")]/child::table/descendant::td", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" Activity \")]"}, {domain:"^https?://www\\.flickr\\.com/explore/$", paragraph:"descendant::div[@id = \"Main\"]", link:"descendant::table[contains(concat(\" \", normalize-space(@class), \" \"), \" Interestingness \")]/child::tbody/child::tr/child::td/child::a", annotation:"descendant::h1"}, {domain:"^https?://niceboat\\.org/$", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*itmedia\\.co\\.jp/[a-z]+/articles/\\d+/\\d+/news[\\d_]+.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" articles \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*itmedia\\.co\\.jp.*/$", paragraph:"descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" headline \")]/descendant::li | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" hl \")]/descendant::li | descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" linkset \")]/descendant::li", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://k\\-ui\\.jp/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" post \")]", link:"descendant::h2/descendant::a", annotation:"descendant::small[contains(concat(\" \", normalize-space(@class), \" \"), \" postmetadata \")]"}, {domain:"^https?://i\\.hatena\\.ne\\.jp/(?!idea(list)?)", paragraph:"descendant::td[contains(concat(\" \", normalize-space(@class), \" \"), \" icontent \")]", link:"descendant::a", annotation:"descendant::div"}, {domain:"^https?://ameblo\\.jp/.*/entry-\\d+\\.html$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://ameblo\\.jp/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" foot \")]/child::a[not(preceding-sibling::*)]", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://ameblo\\.jp/", paragraph:"descendant::article", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" skinArticleHeader2 \")]/descendant::h1/descendant::a", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" skinArticleHeader2 \")]/descendant::h1"}, {domain:"^https?://japan\\.cnet\\.com/news/media/story/\\d+,\\d+,\\d+,\\d+.htm$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" block_leaf \")]", link:"descendant::*[@id = \"sbm_list_url_saaf_EXTPOSITION\"]", annotation:"descendant::h1"}, {domain:"^https?://sankei\\.msn\\.com/\\w+/\\w+/\\d+/\\w+-\\w\\.htm$", paragraph:"descendant::div[@id = \"articleTextnews1\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://serif\\.hatelabo\\.jp/.*$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" serif_data \")]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" serifer \")]"}, {domain:"^https?://itpro\\.nikkeibp\\.co\\.jp/article/", paragraph:"descendant::div[@id = \"kijiBox\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" kijiTitle \")]"}, {domain:"^https?://(?:[w-]+.)*bblog\\.jp/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*bblog\\.jp/monthly/.+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*bblog\\.jp/category/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://(?:[w-]+.)*bblog\\.jp/entry/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/descendant::a[not(preceding-sibling::*)]", annotation:"descendant::h3"}, {domain:"^https?://www\\.konami\\.jp/bemani/gfdm/gfdmv4/music/.*$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entryBox \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h3"}, {domain:"^https?://www\\.tsukimizake\\.com/.*\\.htm$", paragraph:"descendant::*[@id = \"HATENA\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" hatena-star \")]"}, {domain:"^https?://www\\.example\\.org/", paragraph:"descendant::body", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::p[count(preceding-sibling::*) = 1]"}, {domain:"^https?://alpha\\.mixi\\.co\\.jp/blog/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" metadata \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://natalie\\.mu/news/show/id/\\w+$", paragraph:"descendant::*[@id = \"article-title\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[@id = \"article-title\"]"}, {domain:"^https?://detail\\.chiebukuro\\.yahoo\\.co\\.jp/qa/question_detail/q\\d+", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" Extends-details \")]", link:"descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" user-name \")]"}, {domain:"^https?://www\\.misuzilla\\.org/blog/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/child::a", annotation:"descendant::h3[not(preceding-sibling::*)]"}, {domain:"^https?://search\\.cpan\\.org/search", paragraph:"descendant::p", link:"descendant::a[count(preceding-sibling::*) = 1]", annotation:"descendant::small/descendant::a[not(preceding-sibling::*)]"}, {domain:"^https?://search\\.cpan\\.org/~\\w+/.+\\d/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box \") and not(preceding-sibling::*)]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://search\\.cpan\\.org/dist/[^/]+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box \") and not(preceding-sibling::*)]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://search\\.cpan\\.org/~\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box \") and not(preceding-sibling::*)]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" t1 \")]"}, {domain:"^https?://slashdot\\.jp/~\\w+/journal/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalentry \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h3/descendant::a | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalhead \")]/descendant::h2/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalhead \")]/descendant::h2"}, {domain:"^https?://slashdot\\.jp/journal\\.pl?", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalentry \")]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h3/descendant::a | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalhead \")]/descendant::h2/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h3 | descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" journalhead \")]/descendant::h2"}, {domain:"^https?://slashdot\\.jp/.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" commentTop \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" otherdetails \")]/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h4"}, {domain:"^https?://slashdot\\.jp/.*/comments\\.pl?.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" commentTop \")]", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" otherdetails \")]/descendant::a", annotation:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::h4"}, {domain:"^https?://k\\.osx\\.cc/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-info \")]", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-permalink \")]"}, {domain:"^https?://k\\.osx\\.cc/\\d+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-info \")]", link:"descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-permalink \")]"}, {domain:"^https?://blog\\.pasonatech\\.co\\.jp/[\\w-]+/", paragraph:"descendant::h1", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://(?:[w-]+.)*at\\.webry\\.info/\\d+/article_\\d+\\.html", paragraph:"descendant::div[@id = \"blog-head\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*at\\.webry\\.info/($|\\d+/index\\.html|theme/)", paragraph:"descendant::div[@id = \"postlist\"]/descendant::table/descendant::tbody/descendant::tr/descendant::td[not(preceding-sibling::*)]", link:"descendant::a[not(preceding-sibling::*)]", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" response \")]"}, {domain:"^https?://www\\.hatena\\.ne\\.jp/[a-zA-Z][a-zA-Z0-9_-]{1,30}[a-zA-Z0-9]/$", paragraph:"descendant::div[@id = \"header-body\"]/descendant::h1", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://www\\.hatena\\.ne\\.jp/faq/", paragraph:"descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" qaitem \")]", link:"descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" q \")]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" q \")]/descendant::p | descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" q \")]"}, {domain:"^https?://(?:[w-]+.)*jaiku\\.com(/$|/\\??page=\\d)", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" stream \")]/descendant::li[contains(concat(\" \", normalize-space(@class), \" \"), \" presence \")]/descendant::div/descendant::div", link:"descendant::h3/descendant::a", annotation:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" meta \")]"}, {domain:"^https?://(?:[w-]+.)*jaiku\\.com/presence/\\w+", paragraph:"descendant::div[@id = \"current-stream\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://(?:[w-]+.)*blog39\\.fc2\\.com/\\w+/$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://www\\.chikawatanabe\\.com.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" blog \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" posted \")]/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://homepage1\\.nifty\\.com/maname/$|^/maname/log/", paragraph:"descendant::p/descendant::table/descendant::td[not(preceding-sibling::*)]/descendant::table[not(preceding-sibling::*)] | descendant::p/descendant::table/descendant::td[not(preceding-sibling::*)]/descendant::p/descendant::table[not(preceding-sibling::*)]", link:"descendant::a", annotation:"descendant::td"}, {domain:"^https?://ittemia\\.jp/mission_search.php$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" summarySpread \")]", link:"descendant::a", annotation:"descendant::dt"}, {domain:"^https?://ittemia\\.jp/mission_detail.php/mission_id/\\d+$", paragraph:"descendant::div[@id = \"main\"]/child::table/descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" iconLinkNormal \")]", link:"descendant::a", annotation:"descendant::li"}, {domain:"^https?://ittemia\\.jp/all_progress.php\\?search_type=1$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" wordsBalloonAdd \")]", link:"descendant::strong/child::a", annotation:"descendant::dt"}, {domain:"^https?://ittemia\\.jp/progress_detail.php|commu_board_detail.php$", paragraph:"descendant::div[@id = \"main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1[@id = \"pageTitle\"]"}, {domain:"^https?://ittemia\\.jp/all_progress.php\\?search_type=15$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" wordsBalloonAdd \")]", link:"descendant::strong/child::a", annotation:"descendant::dt"}, {domain:"^https?://ittemia\\.jp/all_progress.php$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" wordsBalloonAdd \")]", link:"descendant::strong/child::a", annotation:"descendant::dt"}, {domain:"^https?://ittemia\\.jp/commu_board.php$", paragraph:"descendant::ul[contains(concat(\" \", normalize-space(@class), \" \"), \" iconLinkNormal \")]", link:"descendant::a", annotation:"descendant::li"}, {domain:"^https?://ittemia\\.jp/($|top.php$)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" subColumn \")]/descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" sectionBox \") and count(preceding-sibling::*) = 3]/descendant::dd", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://ittemia\\.jp/zensen/themes/view/\\d+$", paragraph:"descendant::div[@id = \"Container\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" PageTitleType1 \")]"}, {domain:"^https?://ittemia\\.jp/zensen/comments/theme/\\d+$", paragraph:"descendant::div[@id = \"Container\"]", link:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" LocalNaviHorizontalBox \")]/descendant::a", annotation:"descendant::h1[contains(concat(\" \", normalize-space(@class), \" \"), \" PageTitleType1 \")]"}, {domain:"^https?://ittemia\\.jp/zensen/announces/view/\\d+$", paragraph:"descendant::div[@id = \"Container\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://ittemia\\.jp/zensen/announces/$", paragraph:"descendant::dd", link:"descendant::a", annotation:"descendant::li"}, {domain:"^https?://ittemia\\.jp/zensen/$", paragraph:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" SubjectTitle \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://www3\\.nhk\\.or\\.jp.*", paragraph:"descendant::*[@id = \"news_main\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*anisen\\.tv/", paragraph:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]", link:"descendant::a", annotation:"self::*"}, {domain:"^https?://unknownplace\\.org/memo/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3/child::a", annotation:"descendant::h3"}, {domain:"^https?://haropy\\.bloghackers\\.net/entry/.+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" day \")]", link:"descendant::p[contains(concat(\" \", normalize-space(@class), \" \"), \" permalink \")]/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://d\\.hatena\\.ne\\.jp/(?:keyword|asin)/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box-curve-bar \")]", link:"descendant::h2/child::span[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/child::a", annotation:"descendant::h2/child::span[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://d\\.hatena\\.ne\\.jp/(?:keywordlist|hot.*|gourmet/)", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" keyword-list \")]/descendant::li", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://d\\.hatena\\.ne\\.jp/themesample", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" section \")]", link:"descendant::h3/descendant::a", annotation:"descendant::h3"}, {domain:"^https?://d\\.hatena\\.ne\\.jp/[\\w-]+/(?!edit)", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" commentshort \")]/descendant::p", link:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" timestamp \")]/descendant::a", annotation:"descendant::span[contains(concat(\" \", normalize-space(@class), \" \"), \" commentator \")]"}, {domain:"^https?://(?:[w-]+.)*piapro\\.jp/a/content/\\?id=?", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" box11_r_in \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"self::*"}, {domain:"^https?://8bc\\.org/(music|images)\\/.+$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" colmask \") and contains(concat(\" \", normalize-space(@class), \" \"), \" doublepage \")]", link:"descendant::h2/descendant::strong/descendant::a", annotation:"descendant::*[@id = \"media_actions\"]"}, {domain:"^https?://wiki\\.geeko\\.jp/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://youtube\\.com/watch?", paragraph:"descendant::div[@id = \"baseDiv\"]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::*[@id = \"vidTitle\"]"}, {domain:"^https?://bm11\\.kayac\\.com/service/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-body-wrap \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h2"}, {domain:"^https?://bm11\\.kayac\\.com.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry-body-wrap \")]", link:"descendant::h2/descendant::a", annotation:"descendant::h2"}, {domain:"^https?://plus\\.google\\.com/", paragraph:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" a-f-i \")]", link:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" a-f-i-p-U \")]/descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" ot-anchor \")] | descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" a-f-i-p-U \")]/descendant::a[contains(concat(\" \", normalize-space(@class), \" \"), \" a-Ja-h \")]", annotation:"descendant::*[contains(concat(\" \", normalize-space(@class), \" \"), \" a-f-i-bg \")]"}, {domain:"^https?://level0\\.cuppy\\.co\\.jp/\\d{4}/\\d{2}/.*\\.php$", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://level0\\.cuppy\\.co\\.jp.*.*", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" entry \")]", link:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]/descendant::a", annotation:"descendant::h3[contains(concat(\" \", normalize-space(@class), \" \"), \" title \")]"}, {domain:"^https?://(?:[w-]+.)*vox\\.com/library/post/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" asset-name-outer \")]", link:function getLinkToCurrentURI(context) {
    let doc = context.ownerDocument || context;
    // XXX doesn't work in XHTML.
    let apLink = doc.evaluate(
        '(ancestor-or-self::*/preceding-sibling::*' +
            '[@class = "autopagerize_page_info" or @class = "_autopagerize"]' +
        ')[last()]/descendant::a[@class = "autopagerize_link" and @href]',
        context, null, XPathResult.ANY_UNORDERED_NODE_TYPE, null
    ).singleNodeValue;
    let a = doc.createElementNS(XHTML_NS, 'a');
    a.href = apLink ? apLink.href : doc.defaultView.location.href;
    return a;
}, annotation:"descendant::h1"}, {domain:"^https?://(?:[w-]+.)*vox\\.com/", paragraph:"descendant::div[contains(concat(\" \", normalize-space(@class), \" \"), \" asset-header \")]", link:"descendant::h2/child::a", annotation:"descendant::h2"}, {domain:"^https?://www\\.gizmodo\\.jp/$|^/\\d+/\\d+/.*\\.html$|^/mt/mt-search\\.cgi$", paragraph:"descendant::h2", link:"descendant::a", annotation:"self::*"}]})